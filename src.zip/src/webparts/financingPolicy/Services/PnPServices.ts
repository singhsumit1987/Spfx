import { sp } from "@pnp/sp/presets/all";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";

export class PnPServices {

    /** Get All PDF files **/

    public static async _getPolicyDocs(): Promise<any> {
        let allfiles: any[] = [];
        try {
            allfiles = await sp.web.lists.getByTitle("Policy_and_Guidelines").items.filter("File_x0020_Type eq 'pdf'")
                .select("FileLeafRef", "FileRef", "File_x0020_Type", "Title", "Created", "Language").usingCaching().getAll();
            return allfiles;
        }
        catch (error) {
            return allfiles;
        }
    }

    public static async _getLendingDocs(): Promise<any> {
        let allfiles: any[] = [];
        try {
            allfiles = await sp.web.lists.getByTitle("Lending_Financing").items.filter("File_x0020_Type eq 'pdf'")
                .select("FileLeafRef", "FileRef", "File_x0020_Type", "Title", "Created", "Language").usingCaching().getAll();
            return allfiles;
        }
        catch (error) {
            return allfiles;
        }
    }
    public static async _getUsefulLinks(): Promise<any> {
        let allfiles: any[] = [];
        try {
            allfiles = await sp.web.lists.getByTitle("Useful_Links").items
                .select("URL", "LinkType", "Title").usingCaching().getAll();
            return allfiles;
        }
        catch (error) {
            return allfiles;
        }
    }
}