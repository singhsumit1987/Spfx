export class RESTServices {
    public static async _getDataForCountry(countryName: string): Promise<any> {
        try {
            //****REST API TO GET COUNTRY ASSOCIATED DATA******//

            let response = await fetch('https://sposervice.ifad.org/rest/api/debt/Snapshot?countryiso3=' + countryName);
            if (response.ok) {
                const data = response.json();
                console.log(data);
                return data;
            }
            else {
                return null;
            }
            // const demoData = [{
            //     "REPORT_INDICATOR_NAME": "Income group",
            //     "INDICATOR_VALUE": "LIC"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "Least Developed Country",
            //     "INDICATOR_VALUE": "Yes"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "WB Fragility state list",
            //     "INDICATOR_VALUE": "Yes"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "Small State Economy",
            //     "INDICATOR_VALUE": "No"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "Commodity dependent country",
            //     "INDICATOR_VALUE": "No"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "IMF / WB DSA",
            //     "INDICATOR_VALUE": "High/Sustainable (2021/6)"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "Financing Terms",
            //     "INDICATOR_VALUE": "D"
            // },
            // {
            //     "REPORT_INDICATOR_NAME": "IFAD 12 PBAS allocation (US$ million)",
            //     "INDICATOR_VALUE": "25.0"
            // }];
            // return demoData;

        }
        catch (error) {
            return null;
        }
    }
    public static async _getCountryList(): Promise<any> {
        let CountryList: [] = [];
        try {
            let response = await fetch('https://sposervice.ifad.org/rest/api/debt/Divisions');
            if (response.ok) {
                const data = response.json();
                console.log(data);
                return data;
            }
            else {
                return CountryList;
            }
        }
        catch (error) {
            return CountryList;
        }
    }
}