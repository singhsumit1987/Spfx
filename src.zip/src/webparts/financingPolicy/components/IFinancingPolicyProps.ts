export interface IFinancingPolicyProps {
  siteURL: string;
  pageContext: any;
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
}
