/* tslint:disable */
require("./FinancingPolicy.module.css");
const styles = {
  financingPolicy: 'financingPolicy_b998c8c6',
  teams: 'teams_b998c8c6',
  welcome: 'welcome_b998c8c6',
  welcomeImage: 'welcomeImage_b998c8c6',
  links: 'links_b998c8c6',
  column: 'column_b998c8c6',
  row: 'row_b998c8c6',
  pivotPane: 'pivotPane_b998c8c6',
  pivotPaneDocListContainer: 'pivotPaneDocListContainer_b998c8c6',
  pivotPaneDocListContent: 'pivotPaneDocListContent_b998c8c6',
  pivotPaneDebtSustain: 'pivotPaneDebtSustain_b998c8c6',
  customPivotHeader: 'customPivotHeader_b998c8c6',
  'ifad-active': 'ifad-active_b998c8c6',
  ifadDropdown: 'ifadDropdown_b998c8c6',
  ifadTable: 'ifadTable_b998c8c6',
  ifadTableDiv: 'ifadTableDiv_b998c8c6',
  ifadButtonDiv: 'ifadButtonDiv_b998c8c6',
  ifadRow: 'ifadRow_b998c8c6',
  ifadRowStart: 'ifadRowStart_b998c8c6',
  ifadRowMid: 'ifadRowMid_b998c8c6',
  ifadRowEnd: 'ifadRowEnd_b998c8c6',
  ifadStackLink: 'ifadStackLink_b998c8c6',
  ifadLink: 'ifadLink_b998c8c6',
  ifadPDFMetadata: 'ifadPDFMetadata_b998c8c6',
  ifadHomeRightPane: 'ifadHomeRightPane_b998c8c6',
  ifadHomeRightPaneHeader: 'ifadHomeRightPaneHeader_b998c8c6',
  iframeHostDiv: 'iframeHostDiv_b998c8c6',
  iframeContentClass: 'iframeContentClass_b998c8c6'
};

export default styles;
/* tslint:enable */