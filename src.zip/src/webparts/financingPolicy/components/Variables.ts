//import { DefaultPalette } from '@fluentui/react'

export const ifadColor = '#0f518f';
export const countryList = [
    {
        key: "AFG",
        text: "AFGHANISTAN"
    },
    {
        key: "AGO",
        text: "ANGOLA"
    },
    {
        key: "ARG",
        text: "ARGENTINA"
    },
    {
        key: "ARM",
        text: "ARMENIA"
    },
    {
        key: "BGD",
        text: "BANGLADESH"
    },
    {
        key: "BLZ",
        text: "BELIZE"
    },
    {
        key: "BEN",
        text: "BENIN"
    },
    {
        key: "BTN",
        text: "BHUTAN"
    },
    {
        key: "BOL",
        text: "BOLIVIA"
    },
    {
        key: "BIH",
        text: "BOSNIA AND HERZEGOVINA"
    },
    {
        key: "BRA",
        text: "BRAZIL"
    },
    {
        key: "BFA",
        text: "BURKINA FASO"
    },
    {
        key: "BDI",
        text: "BURUNDI"
    },
    {
        key: "KHM",
        text: "CAMBODIA"
    },
    {
        key: "CMR",
        text: "CAMEROON"
    },
    {
        key: "CPV",
        text: "CAPE VERDE"
    },
    {
        key: "CAF",
        text: "CENTRAL AFRICAN REPUBLIC"
    },
    {
        key: "TCD",
        text: "CHAD"
    },
    {
        key: "CHN",
        text: "CHINA"
    },
    {
        key: "COL",
        text: "COLOMBIA"
    },
    {
        key: "COM",
        text: "COMOROS"
    },
    {
        key: "COG",
        text: "CONGO"
    },
    {
        key: "COD",
        text: "CONGO, THE DEMOCRATIC REPUBLIC"
    },
    {
        key: "CIV",
        text: "COTE D'IVOIRE"
    },
    {
        key: "CUB",
        text: "CUBA"
    },
    {
        key: "DJI",
        text: "DJIBOUTI"
    },
    {
        key: "DOM",
        text: "DOMINICAN REPUBLIC"
    },
    {
        key: "ECU",
        text: "ECUADOR"
    },
    {
        key: "EGY",
        text: "EGYPT"
    },
    {
        key: "SLV",
        text: "EL SALVADOR"
    },
    {
        key: "ERI",
        text: "ERITREA"
    },
    {
        key: "SWZ",
        text: "ESWATINI"
    },
    {
        key: "ETH",
        text: "ETHIOPIA"
    },
    {
        key: "GAB",
        text: "GABON"
    },
    {
        key: "GMB",
        text: "GAMBIA"
    },
    {
        key: "GEO",
        text: "GEORGIA"
    },
    {
        key: "GHA",
        text: "GHANA"
    },
    {
        key: "GRD",
        text: "GRENADA"
    },
    {
        key: "GTM",
        text: "GUATEMALA"
    },
    {
        key: "GIN",
        text: "GUINEA"
    },
    {
        key: "GNB",
        text: "GUINEA-BISSAU"
    },
    {
        key: "GUY",
        text: "GUYANA"
    },
    {
        key: "HTI",
        text: "HAITI"
    },
    {
        key: "HND",
        text: "HONDURAS"
    },
    {
        key: "IND",
        text: "INDIA"
    },
    {
        key: "IDN",
        text: "INDONESIA"
    },
    {
        key: "IRQ",
        text: "IRAQ"
    },
    {
        key: "JOR",
        text: "JORDAN"
    },
    {
        key: "KEN",
        text: "KENYA"
    },
    {
        key: "KIR",
        text: "KIRIBATI"
    },
    {
        key: "KGZ",
        text: "KYRGYZSTAN"
    },
    {
        key: "LAO",
        text: "LAO PEOPLE'S DEMOCRATIC REP"
    },
    {
        key: "LBN",
        text: "LEBANON"
    },
    {
        key: "LSO",
        text: "LESOTHO"
    },
    {
        key: "LBR",
        text: "LIBERIA"
    },
    {
        key: "MDG",
        text: "MADAGASCAR"
    },
    {
        key: "MWI",
        text: "MALAWI"
    },
    {
        key: "MDV",
        text: "MALDIVES"
    },
    {
        key: "MLI",
        text: "MALI"
    },
    {
        key: "MRT",
        text: "MAURITANIA"
    },
    {
        key: "MEX",
        text: "MEXICO"
    },
    {
        key: "MDA",
        text: "MOLDOVA, REPUBLIC OF"
    },
    {
        key: "MNG",
        text: "MONGOLIA"
    },
    {
        key: "MNE",
        text: "MONTENEGRO"
    },
    {
        key: "MAR",
        text: "MOROCCO"
    },
    {
        key: "MOZ",
        text: "MOZAMBIQUE"
    },
    {
        key: "MMR",
        text: "MYANMAR"
    },
    {
        key: "NPL",
        text: "NEPAL"
    },
    {
        key: "NIC",
        text: "NICARAGUA"
    },
    {
        key: "NER",
        text: "NIGER"
    },
    {
        key: "NGA",
        text: "NIGERIA"
    },
    {
        key: "PAK",
        text: "PAKISTAN"
    },
    {
        key: "PSE",
        text: "PALESTINIAN TERRITORY"
    },
    {
        key: "PNG",
        text: "PAPUA NEW GUINEA"
    },
    {
        key: "PRY",
        text: "PARAGUAY"
    },
    {
        key: "PER",
        text: "PERU"
    },
    {
        key: "PHL",
        text: "PHILIPPINES"
    },
    {
        key: "RWA",
        text: "RWANDA"
    },
    {
        key: "WSM",
        text: "SAMOA"
    },
    {
        key: "STP",
        text: "SAO TOME AND PRINCIPE"
    },
    {
        key: "SEN",
        text: "SENEGAL"
    },
    {
        key: "SLE",
        text: "SIERRA LEONE"
    },
    {
        key: "SLB",
        text: "SOLOMON ISLANDS"
    },
    {
        key: "SOM",
        text: "SOMALIA"
    },
    {
        key: "SSD",
        text: "SOUTH SUDAN"
    },
    {
        key: "LKA",
        text: "SRI LANKA"
    },
    {
        key: "SDN",
        text: "SUDAN"
    },
    {
        key: "SYR",
        text: "SYRIAN ARAB REPUBLIC"
    },
    {
        key: "TJK",
        text: "TAJIKISTAN"
    },
    {
        key: "TZA",
        text: "TANZANIA, UNITED REPUBLIC OF"
    },
    {
        key: "TLS",
        text: "TIMOR-LESTE"
    },
    {
        key: "TGO",
        text: "TOGO"
    },
    {
        key: "TON",
        text: "TONGA"
    },
    {
        key: "TUN",
        text: "TUNISIA"
    },
    {
        key: "TUR",
        text: "TURKEY"
    },
    {
        key: "UGA",
        text: "UGANDA"
    },
    {
        key: "UZB",
        text: "UZBEKISTAN"
    },
    {
        key: "VUT",
        text: "VANUATU"
    },
    {
        key: "VNM",
        text: "VIET NAM"
    },
    {
        key: "YEM",
        text: "YEMEN"
    },
    {
        key: "ZMB",
        text: "ZAMBIA"
    },
    {
        key: "ZWE",
        text: "ZIMBABWE"
    }
];

export const countryList_1 = [
    {
        value: "AFG",
        label: "AFGHANISTAN"
    },
    {
        value: "AGO",
        label: "ANGOLA"
    },
    {
        value: "ARG",
        label: "ARGENTINA"
    },
    {
        value: "ARM",
        label: "ARMENIA"
    },
    {
        value: "BGD",
        label: "BANGLADESH"
    },
    {
        value: "BLZ",
        label: "BELIZE"
    },
    {
        value: "BEN",
        label: "BENIN"
    },
    {
        value: "BTN",
        label: "BHUTAN"
    },
    {
        value: "BOL",
        label: "BOLIVIA"
    },
    {
        value: "BIH",
        label: "BOSNIA AND HERZEGOVINA"
    },
    {
        value: "BRA",
        label: "BRAZIL"
    },
    {
        value: "BFA",
        label: "BURKINA FASO"
    },
    {
        value: "BDI",
        label: "BURUNDI"
    },
    {
        value: "KHM",
        label: "CAMBODIA"
    },
    {
        value: "CMR",
        label: "CAMEROON"
    },
    {
        value: "CPV",
        label: "CAPE VERDE"
    },
    {
        value: "CAF",
        label: "CENTRAL AFRICAN REPUBLIC"
    },
    {
        value: "TCD",
        label: "CHAD"
    },
    {
        value: "CHN",
        label: "CHINA"
    },
    {
        value: "COL",
        label: "COLOMBIA"
    },
    {
        value: "COM",
        label: "COMOROS"
    },
    {
        value: "COG",
        label: "CONGO"
    },
    {
        value: "COD",
        label: "CONGO, THE DEMOCRATIC REPUBLIC"
    },
    {
        value: "CIV",
        label: "COTE D'IVOIRE"
    },
    {
        value: "CUB",
        label: "CUBA"
    },
    {
        value: "DJI",
        label: "DJIBOUTI"
    },
    {
        value: "DOM",
        label: "DOMINICAN REPUBLIC"
    },
    {
        value: "ECU",
        label: "ECUADOR"
    },
    {
        value: "EGY",
        label: "EGYPT"
    },
    {
        value: "SLV",
        label: "EL SALVADOR"
    },
    {
        value: "ERI",
        label: "ERITREA"
    },
    {
        value: "SWZ",
        label: "ESWATINI"
    },
    {
        value: "ETH",
        label: "ETHIOPIA"
    },
    {
        value: "GAB",
        label: "GABON"
    },
    {
        value: "GMB",
        label: "GAMBIA"
    },
    {
        value: "GEO",
        label: "GEORGIA"
    },
    {
        value: "GHA",
        label: "GHANA"
    },
    {
        value: "GRD",
        label: "GRENADA"
    },
    {
        value: "GTM",
        label: "GUATEMALA"
    },
    {
        value: "GIN",
        label: "GUINEA"
    },
    {
        value: "GNB",
        label: "GUINEA-BISSAU"
    },
    {
        value: "GUY",
        label: "GUYANA"
    },
    {
        value: "HTI",
        label: "HAITI"
    },
    {
        value: "HND",
        label: "HONDURAS"
    },
    {
        value: "IND",
        label: "INDIA"
    },
    {
        value: "IDN",
        label: "INDONESIA"
    },
    {
        value: "IRQ",
        label: "IRAQ"
    },
    {
        value: "JOR",
        label: "JORDAN"
    },
    {
        value: "KEN",
        label: "KENYA"
    },
    {
        value: "KIR",
        label: "KIRIBATI"
    },
    {
        value: "KGZ",
        label: "KYRGYZSTAN"
    },
    {
        value: "LAO",
        label: "LAO PEOPLE'S DEMOCRATIC REP"
    },
    {
        value: "LBN",
        label: "LEBANON"
    },
    {
        value: "LSO",
        label: "LESOTHO"
    },
    {
        value: "LBR",
        label: "LIBERIA"
    },
    {
        value: "MDG",
        label: "MADAGASCAR"
    },
    {
        value: "MWI",
        label: "MALAWI"
    },
    {
        value: "MDV",
        label: "MALDIVES"
    },
    {
        value: "MLI",
        label: "MALI"
    },
    {
        value: "MRT",
        label: "MAURITANIA"
    },
    {
        value: "MEX",
        label: "MEXICO"
    },
    {
        value: "MDA",
        label: "MOLDOVA, REPUBLIC OF"
    },
    {
        value: "MNG",
        label: "MONGOLIA"
    },
    {
        value: "MNE",
        label: "MONTENEGRO"
    },
    {
        value: "MAR",
        label: "MOROCCO"
    },
    {
        value: "MOZ",
        label: "MOZAMBIQUE"
    },
    {
        value: "MMR",
        label: "MYANMAR"
    },
    {
        value: "NPL",
        label: "NEPAL"
    },
    {
        value: "NIC",
        label: "NICARAGUA"
    },
    {
        value: "NER",
        label: "NIGER"
    },
    {
        value: "NGA",
        label: "NIGERIA"
    },
    {
        value: "PAK",
        label: "PAKISTAN"
    },
    {
        value: "PSE",
        label: "PALESTINIAN TERRITORY"
    },
    {
        value: "PNG",
        label: "PAPUA NEW GUINEA"
    },
    {
        value: "PRY",
        label: "PARAGUAY"
    },
    {
        value: "PER",
        label: "PERU"
    },
    {
        value: "PHL",
        label: "PHILIPPINES"
    },
    {
        value: "RWA",
        label: "RWANDA"
    },
    {
        value: "WSM",
        label: "SAMOA"
    },
    {
        value: "STP",
        label: "SAO TOME AND PRINCIPE"
    },
    {
        value: "SEN",
        label: "SENEGAL"
    },
    {
        value: "SLE",
        label: "SIERRA LEONE"
    },
    {
        value: "SLB",
        label: "SOLOMON ISLANDS"
    },
    {
        value: "SOM",
        label: "SOMALIA"
    },
    {
        value: "SSD",
        label: "SOUTH SUDAN"
    },
    {
        value: "LKA",
        label: "SRI LANKA"
    },
    {
        value: "SDN",
        label: "SUDAN"
    },
    {
        value: "SYR",
        label: "SYRIAN ARAB REPUBLIC"
    },
    {
        value: "TJK",
        label: "TAJIKISTAN"
    },
    {
        value: "TZA",
        label: "TANZANIA, UNITED REPUBLIC OF"
    },
    {
        value: "TLS",
        label: "TIMOR-LESTE"
    },
    {
        value: "TGO",
        label: "TOGO"
    },
    {
        value: "TON",
        label: "TONGA"
    },
    {
        value: "TUN",
        label: "TUNISIA"
    },
    {
        value: "TUR",
        label: "TURvalue"
    },
    {
        value: "UGA",
        label: "UGANDA"
    },
    {
        value: "UZB",
        label: "UZBEKISTAN"
    },
    {
        value: "VUT",
        label: "VANUATU"
    },
    {
        value: "VNM",
        label: "VIET NAM"
    },
    {
        value: "YEM",
        label: "YEMEN"
    },
    {
        value: "ZMB",
        label: "ZAMBIA"
    },
    {
        value: "ZWE",
        label: "ZIMBABWE"
    }

];
