import { IStackItemStyles, IStackStyles, IStackTokens, IconButton, Separator, Stack } from '@fluentui/react';
import * as moment from 'moment';
import * as React from 'react';
import DocViewer, { DocViewerRenderers } from 'react-doc-viewer';
import styles from './FinancingPolicy.module.scss';
import { ifadColor } from './Variables';

const stackStyles: IStackStyles = {
    root: {
        // background: DefaultPalette.themeTertiary,
        width: '100%'
    },
};
const stackTokens: IStackTokens = {
    childrenGap: 5,
    // padding: 10,
};
const stackItemStylesBlank: IStackItemStyles = {
    root: {
        // alignItems: 'center',
        // background: DefaultPalette.themePrimary,
        // color: DefaultPalette.white,
        display: 'flex',
        maxHeight: 600,
        width: '5%'
        // justifyContent: 'center',
    },
};
const stackItemStylesPane: IStackItemStyles = {
    root: {
        // alignItems: 'center',
        // background: DefaultPalette.themePrimary,
        // color: DefaultPalette.white,
        display: 'flex',
        height: 1000,
        width: '50%'
        // justifyContent: 'center',
    },
};
const stackItemStylesList: IStackItemStyles = {
    root: {
        alignItems: 'start',
        // background: DefaultPalette.themePrimary,
        // color: DefaultPalette.white,
        display: 'flex',
        maxHeight: 1000,
        justifyContent: 'start',
        width: '45%'
    },
};
//Vertical Stack definition
const stackItemStylesVertical: IStackItemStyles = {
    root: {
        // background: DefaultPalette.themePrimary,
        // color: DefaultPalette.white,
        display: 'flex',
        padding: 5,
        alignItems: 'center',
        borderBottom: '1.5px solid',
        borderColor: ifadColor,
        cursor: 'pointer',
        borderImage: 'linear-gradient(to right, transparent, rgb(15, 81, 143) 50%, transparent) 1'
    },
};

const itemAlignmentsStackTokens: IStackTokens = {
    childrenGap: 5,
    // padding: 10,
};


export interface PDFPaneComponentProps {
    pdfFiles: any;
    siteURL: string;
    // onClick: (item: any, param: string, index: number) => void;
}
export interface PDFComponentState {
    selectedFilePath: string;
    selectedIndex: number;
}
class PDFPaneComponent extends React.Component<PDFPaneComponentProps, PDFComponentState> {
    constructor(props: PDFPaneComponentProps) {
        super(props);
        this.state = {
            selectedFilePath: '',
            selectedIndex: 0
        }
    };

    public componentDidMount(): void {
        this.setState({
            selectedFilePath: this.props.pdfFiles.length > 0 ? this.props.pdfFiles[0]['FileRef'] : '',
            selectedIndex: this.props.pdfFiles.length > 0 ? 1 : 0,
        })
    }

    //Download file from SharePoint Library
    public _downloadFile = (path: any) => {
        const _domainURL = this.props.siteURL.substring(0, this.props.siteURL.toLowerCase().lastIndexOf("/sites"));
        const _downloadURL = this.props.siteURL + '/_layouts/download.aspx?SourceUrl=' + _domainURL + path;
        window.open(_downloadURL, "_blank");
    }

    //Get the selected file on click
    public _handleClick = (path: any, index: number) => {
        this.setState({
            selectedFilePath: path,
            selectedIndex: index
        });
    }
    render() {
        return <Stack enableScopedSelectors horizontal tokens={stackTokens}>
            <Stack.Item grow={2} styles={stackItemStylesList} className={styles.pivotPaneDocListContainer}>
                <Stack enableScopedSelectors styles={stackStyles} tokens={itemAlignmentsStackTokens} className={styles.pivotPaneDocListContent}>
                    {this.props.pdfFiles.length > 0 &&
                        this.props.pdfFiles.map((_item: any, i = 0) => {
                            return (
                                <Stack.Item align="auto" styles={stackItemStylesVertical} tabIndex={i + 1}
                                    onClick={() => this.state.selectedIndex != i + 1 ? this._handleClick(_item["FileRef"], i + 1) : undefined}
                                    className={this.state.selectedIndex == i + 1 ? styles['ifad-active'] : ''}>
                                    <span dangerouslySetInnerHTML={{ __html: _item["FileLeafRef"] }} style={{ width: '50%' }} >
                                    </span>
                                    <span dangerouslySetInnerHTML={{ __html: _item["Language"] }} style={{ width: '15%' }} className={styles.ifadPDFMetadata}>
                                    </span>
                                    <span style={{ width: '15%' }} className={styles.ifadPDFMetadata}>
                                        {moment(_item["Created"]).format('MMMM YYYY')}
                                    </span>
                                    <span style={{ width: '10%' }} className={styles.ifadPDFMetadata}><IconButton iconProps={{ iconName: "CloudDownload" }} title="CloudDownload" ariaLabel="CloudDownload"
                                        onClick={() => this._downloadFile(_item["FileRef"])} />
                                    </span>
                                    <span style={{ width: '10%' }} className={styles.ifadPDFMetadata}><IconButton iconProps={{ iconName: "View" }} title="View" ariaLabel="View" />
                                    </span>
                                </Stack.Item>
                            );
                        })}
                </Stack>
            </Stack.Item>
            <Stack.Item styles={stackItemStylesBlank}>
                <div style={{ width: '50px' }}>
                    <Separator vertical />
                </div>
            </Stack.Item>
            <Stack.Item grow={3} styles={stackItemStylesPane}>
                <div style={{
                    border: '1px solid rgba(0, 0, 0, 0.3)',
                    height: '600px',
                    width: '100%'
                }}>
                    <DocViewer pluginRenderers={DocViewerRenderers} style={{ width: '100%', height: "100%" }}
                        config={{
                            header: {
                                disableHeader: false,
                                disableFileName: false,
                                retainURLParams: false
                            }
                        }}
                        documents={[
                            {
                                uri: this.state.selectedFilePath
                            }
                        ]}
                    />
                </div>
            </Stack.Item>
        </Stack>;
    }
}

export default PDFPaneComponent;
