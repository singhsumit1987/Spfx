export interface IFinancingPolicyState {
    policyPdfFiles?: any;
    lendingPdfFiles?: any;
    selectedPolicyFilePath?: any;
    selectedPolicyFileIndex?: number;
    selectedLendingFilePath?: any;
    selectedLendingFileIndex?: number;
    countryList?: any;
    selectedCountry?: any;
    countryData?: any;
    dataModal?: boolean;
    usefulLinks?: any;
}