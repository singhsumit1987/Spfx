import * as React from 'react';
import styles from './FinancingPolicy.module.scss';
import type { IFinancingPolicyProps } from './IFinancingPolicyProps';
import { IFinancingPolicyState } from './IFinancingPolicyState';
//import { escape } from '@microsoft/sp-lodash-subset';

import { FontWeights, IButtonStyles, IconButton, Modal, Pivot, PivotItem, PrimaryButton, Separator, getTheme, mergeStyleSets } from '@fluentui/react';
import { Stack, IStackStyles, IStackTokens, IStackItemStyles } from '@fluentui/react';
import { PnPServices } from '../Services/PnPServices';
import { countryList, ifadColor, countryList_1 } from './Variables';

import * as moment from "moment-timezone";
import Select from 'react-select';

//Doc Viewer
import DocViewer, { DocViewerRenderers } from "react-doc-viewer";
import { RESTServices } from '../Services/RESTServices';

//#region Inline Styling STARTS

//#region Pivot Styling
const pivotStyles = {
  linkIsSelected: {
    'background-color': '#d1dae3 !important',
    'color': 'black !important',
    'font-weight': 400
  },
  link: {
    'border-radius': '5px 5px 0px 0px;',
    'margin-right': '6px',
    'background-color': 'rgb(0, 120, 212)',
    'color': 'rgb(255, 255, 255)',
    'font-weight': 400
  },
  root: {
    'display': 'flex',
    'justify-content': 'center'
  }
};
//#endregion

// Styles definition
const stackStyles: IStackStyles = {
  root: {
    // background: DefaultPalette.themeTertiary,
    width: '100%'
  },
};
// Tokens definition
const stackTokens: IStackTokens = {
  childrenGap: 5,
  // padding: 10,
};

//#region HOME TAB STYLING
const stackItemStyles: IStackItemStyles = {
  root: {
    alignItems: 'start',
    display: 'flex',
    height: 700,
    // justifyContent: 'center',
    padding: '0px 10px 0px 10px',
    color: ifadColor,
    borderRadius: 10
  },
};
const verticalItemStackStyles: IStackItemStyles = {
  root: {
    display: 'flex',
    // padding: 10,
    // justifyContent: 'center'
  }
};
const stackItemStylesMIddlePane: IStackItemStyles = {
  root: {
    padding: 5,
  },
};

// const dropdownStyles: Partial<IDropdownStyles> = {
//   dropdown: { width: 250 },
//   dropdownOptionText: { overflow: 'visible', whiteSpace: 'normal' },
//   // dropdownItem: { height: 'auto' },
//   dropdownItemsWrapper: { height: 300 },
//   dropdownItemSelected: {
//     selectors: {
//       '&:before': {
//         content: '""',
//         position: 'absolute',
//         left: 0,
//         top: 0,
//         bottom: 0,
//         width: '4px',
//         background: 'rgb(0, 120, 212)',
//       },
//     },
//   },
// };

const theme = getTheme();
const contentStyles = mergeStyleSets({
  container: {
    display: 'flex',
    flexFlow: 'column nowrap',
    alignItems: 'stretch',
    width: 800
  },
  header: [
    // eslint-disable-next-line deprecation/deprecation
    theme.fonts.xLargePlus,
    {
      flex: '1 1 auto',
      borderTop: `4px solid ${theme.palette.themePrimary}`,
      color: theme.palette.neutralPrimary,
      display: 'flex',
      alignItems: 'center',
      fontWeight: FontWeights.semibold,
      padding: '12px 12px 14px 24px',
    },
  ],
  heading: {
    color: theme.palette.neutralPrimary,
    fontWeight: FontWeights.semibold,
    fontSize: 'inherit',
    margin: '0',
  },
  body: {
    flex: '4 4 auto',
    padding: '0 24px 24px 24px',
    overflowY: 'hidden',
    selectors: {
      p: { margin: '14px 0' },
      'p:first-child': { marginTop: 0 },
      'p:last-child': { marginBottom: 0 },
    },
  },
});
const iconButtonStyles: Partial<IButtonStyles> = {
  root: {
    color: theme.palette.neutralPrimary,
    marginLeft: 'auto',
    marginTop: '4px',
    marginRight: '2px',
  },
  rootHovered: {
    color: theme.palette.neutralDark,
  },
};
//#endregion

//#region POLICY AND LENDING TAB STYLING
const stackItemStylesBlank: IStackItemStyles = {
  root: {
    // alignItems: 'center',
    // background: DefaultPalette.themePrimary,
    // color: DefaultPalette.white,
    display: 'flex',
    maxHeight: 600,
    width: '5%'
    // justifyContent: 'center',
  },
};
const stackItemStylesPane: IStackItemStyles = {
  root: {
    // alignItems: 'center',
    // background: DefaultPalette.themePrimary,
    // color: DefaultPalette.white,
    display: 'flex',
    height: 600,
    width: '50%'
    // justifyContent: 'center',
  },
};
const stackItemStylesList: IStackItemStyles = {
  root: {
    alignItems: 'start',
    // background: DefaultPalette.themePrimary,
    // color: DefaultPalette.white,
    display: 'flex',
    maxHeight: 600,
    justifyContent: 'start',
    width: '45%'
  },
};

//Vertical Stack definition
const stackItemStylesVertical: IStackItemStyles = {
  root: {
    // background: DefaultPalette.themePrimary,
    // color: DefaultPalette.white,
    display: 'flex',
    padding: 5,
    alignItems: 'center',
    border: '1px solid',
    borderRadius: 5,
    borderColor: ifadColor,
  },
};

const itemAlignmentsStackTokens: IStackTokens = {
  childrenGap: 5,
  // padding: 10,
};
//#endregion

//#endregion Inline Stylings ENDS


export default class FinancingPolicy extends React.Component<IFinancingPolicyProps, IFinancingPolicyState> {
  public constructor(props: IFinancingPolicyProps, state: IFinancingPolicyState) {
    super(props);
    this.state = {
      policyPdfFiles: [],
      lendingPdfFiles: [],
      selectedPolicyFilePath: '',
      selectedPolicyFileIndex: 0,
      selectedLendingFilePath: '',
      selectedLendingFileIndex: 0,
      countryList: [],
      selectedCountry: {},
      countryData: null,
      dataModal: false
    };
  }
  async componentDidMount(): Promise<void> {
    await this._getAllFiles();
  }
  public _getAllFiles = async () => {
    const allPolicyFiles = await PnPServices._getPolicyDocs();
    const allLendingFiles = await PnPServices._getLendingDocs();
    console.log(allPolicyFiles);
    console.log(allLendingFiles);
    this.setState({
      policyPdfFiles: allPolicyFiles,
      selectedPolicyFilePath: allPolicyFiles.length > 0 ? allPolicyFiles[0]['FileRef'] : '',
      selectedPolicyFileIndex: allPolicyFiles.length > 0 ? 1 : 0,
      lendingPdfFiles: allLendingFiles,
      selectedLendingFilePath: allLendingFiles.length > 0 ? allLendingFiles[0]['FileRef'] : '',
      selectedLendingFileIndex: allLendingFiles.length > 0 ? 1 : 0,
      countryList: countryList,
    });
  }



  //Download file from SharePoint Library
  public _downloadFile = (path: any) => {
    const _domainURL = this.props.siteURL.substring(0, this.props.siteURL.toLowerCase().lastIndexOf("/sites"));
    const _downloadURL = this.props.siteURL + '/_layouts/download.aspx?SourceUrl=' + _domainURL + path;
    window.open(_downloadURL, "_blank");
  }

  //Get the selected file on click
  public _selectFile = (path: any, param: string, index: number) => {
    switch (param) {
      case 'policy':
        this.setState({
          selectedPolicyFilePath: path,
          selectedPolicyFileIndex: index
        });
        break;
      case 'lending':
        this.setState({
          selectedLendingFilePath: path,
          selectedLendingFileIndex: index
        });
        break;
    }
  }

  //Get selected country and associated date
  public _selectedCountry = async (event: any) => {
    console.log(event);
    let countryData = await RESTServices._getDataForCountry(event.value);
    this.setState({
      selectedCountry: event,
      countryData: countryData
    });
  }

  public _onModalOpen = () => {
    this.setState({
      dataModal: true
    })
  }

  public render(): React.ReactElement<IFinancingPolicyProps> {
    const { countryData } = this.state;
    return (
      <div className={styles.financingPolicy}>
        <div className='fluentUI-CSS'>
          <Pivot aria-label="IFAD-PIVOT" linkFormat="tabs" linkSize="normal" styles={pivotStyles}>
            <PivotItem headerText="HOME" className={styles.customPivotHeader} ariaLabel='home' >
              <div className={styles.pivotPane}>
                <Stack enableScopedSelectors horizontal styles={stackStyles} tokens={stackTokens}>
                  <Stack.Item grow={2} styles={stackItemStyles} aria-label='dropdownPane' style={{ width: '30%', background: '#b6cee5' }}>
                    <Stack tokens={stackTokens} style={{ width: '100%' }}>
                      <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'center' }}>
                        <h2>Country Snapshot</h2>
                      </Stack.Item>
                      {/* <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                        <Dropdown
                          placeholder="Select a country"
                          options={this.state.countryList}
                          styles={dropdownStyles}
                          selectedKey={this.state.selectedCountry ? this.state.selectedCountry.key : undefined}
                          onChange={this._selectedCountry}
                        />
                      </Stack.Item> */}
                      <Stack.Item styles={verticalItemStackStyles} style={{ margin: '5% 5% 0% 5%' }}>
                        <span>Select a country</span>
                      </Stack.Item>
                      <Stack.Item styles={verticalItemStackStyles} style={{ margin: '5% 5% 0% 5%' }}>
                        <Select
                          className={styles.ifadDropdown}
                          classNamePrefix="ifadCountry"
                          placeholder="Select a country"
                          value={this.state.selectedCountry}
                          isLoading={false}
                          isSearchable={true}
                          name="ifad-country"
                          options={countryList_1}
                          onChange={this._selectedCountry}
                          noOptionsMessage={() => "No country to select"}
                        />
                      </Stack.Item>
                      <Stack.Item styles={verticalItemStackStyles} style={{ margin: '5%' }}>
                        <table>
                          <tr>
                            Income Group: {countryData ? countryData['Income group'] : ''}
                          </tr>
                          <tr>
                            Least Developed Country:{countryData ? countryData['Least Developed Country'] : ''}
                          </tr>
                          <tr>
                            WB Fragility state list:{countryData ? countryData['WB Fragility state list'] : ''}
                          </tr>
                          <tr>
                            Small State Economy:{countryData ? countryData['Small State Economy'] : ''}
                          </tr>
                          <tr>
                            Commodity dependent country:{countryData ? countryData['Commodity dependent country'] : ''}
                          </tr>
                          <tr>
                            IMF /WB DSA:{countryData ? countryData['IMF /WB DSA'] : ''}
                          </tr>
                          <tr>
                            Financing Terms:{countryData ? countryData['Financing Terms'] : ''}
                          </tr>
                          <tr>
                            {countryData ? 'IFAD 12 PBAS allocation (US$ million): ' + countryData['IFAD 12 PBAS allocation (US$ million)'] : 'IFAD 11 allocation (US$ million):'}
                          </tr>
                        </table>
                      </Stack.Item>
                      {!countryData &&
                        <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'end', margin: '0% 5% 0% 0%' }}>
                          <PrimaryButton text="Generate Country Snapshot" allowDisabledFocus onClick={() => this._onModalOpen()} />
                        </Stack.Item>
                      }
                    </Stack>
                  </Stack.Item>
                  <Stack.Item grow={3} styles={stackItemStyles} aria-label='middlePane' style={{ width: '50%' }}>
                    <Stack enableScopedSelectors styles={stackStyles} tokens={{ childrenGap: 5, padding: 10 }}>
                      <Stack.Item align="center" styles={stackItemStylesMIddlePane}>
                        <h2>Welcome to the IFAD Debt Page</h2>
                      </Stack.Item>
                      <Stack.Item align="start" styles={stackItemStylesMIddlePane}>
                        <p>This webpage aims to function as a one-point, user-friendly and dynamic platform to provide key information and resources to support IFAD staff in their work related with IFAD lending and financing terms and debt sustainability of the borrowing countries. Resources made available on this site include:
                          <ul>
                            <li>IFAD financing policy and guidelines</li>
                            <li>IFAD lending terms and financing terms</li>
                            <li>Interactive status table and links to reports of Debt Sustainability Analysis</li>
                            <li>Country economic/debt snapshot</li>
                          </ul>
                        </p>
                        <p>If you encounter any problems while using the site, have any questions or further suggestions, please contact: <a href="mailto:lt_ft@ifad.org">lt_ft@ifad.org</a></p>
                      </Stack.Item>
                    </Stack>
                  </Stack.Item>
                  <Stack.Item grow styles={stackItemStyles} aria-label='rightPane' style={{ width: '20%' }}>
                    <Stack tokens={stackTokens}>
                      <Stack.Item style={{ background: '#b6cee5', borderRadius: '10px', padding: 15 }}>
                        <Stack tokens={stackTokens}>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'center' }}>
                            <h2>Useful Links</h2>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">IMF MAC-DSA</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">IMF LIC-DSA</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">World Bank Debt</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">IDA Debt</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">Core Principles on Sustainable Financing</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">World Bank Interactive Guide on LIC-DSA</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">LMS LT FT Course</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">IDA Grant Element Calculator</a>
                          </Stack.Item>
                        </Stack>
                      </Stack.Item>
                      <Stack.Item >
                        <Stack tokens={stackTokens}>
                          <Stack.Item styles={verticalItemStackStyles} >
                            <div style={{ height: 30, justifyContent: 'start' }}>

                            </div>
                          </Stack.Item>
                        </Stack>
                      </Stack.Item>
                      <Stack.Item style={{ background: '#b6cee5', borderRadius: '10px', padding: 15 }}>
                        <Stack tokens={stackTokens}>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'center' }}>
                            <h2>Development Finance Blog</h2>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">IFAD Coordinates with WB and IFls on the Core</a>
                          </Stack.Item>
                          <Stack.Item styles={verticalItemStackStyles} style={{ justifyContent: 'start' }}>
                            <a href="#">Principles on Sustainable Financing</a>
                          </Stack.Item>
                        </Stack>
                      </Stack.Item>
                    </Stack>
                  </Stack.Item>
                </Stack>
              </div>
            </PivotItem>
            <PivotItem headerText="POLICY AND GUIDELINES" className={styles.customPivotHeader} >
              <div className={styles.pivotPane}>
                <h1>Policy and Guidelines</h1>
                <Stack enableScopedSelectors horizontal tokens={stackTokens}>
                  <Stack.Item grow={2} styles={stackItemStylesList} className={styles.pivotPaneDocListContainer}>
                    <Stack enableScopedSelectors styles={stackStyles} tokens={itemAlignmentsStackTokens} style={{ margin: 10 }}>
                      {this.state.policyPdfFiles.length > 0 &&
                        this.state.policyPdfFiles.map((_item: any, i = 0) => {
                          return (
                            <Stack.Item align="auto" styles={stackItemStylesVertical} tabIndex={i + 1} onClick={() => this._selectFile(_item["FileRef"], 'policy', i + 1)} className={this.state.selectedPolicyFileIndex == i + 1 ? styles['ifad-active'] : ''}>
                              <span dangerouslySetInnerHTML={{ __html: _item["FileLeafRef"] }} style={{ width: '50%' }}>
                              </span>
                              <span dangerouslySetInnerHTML={{ __html: _item["Language"] }} style={{ width: '15%' }}>
                              </span>
                              <span style={{ width: '15%' }}>
                                {moment(_item["Created"]).format('MMMM YYYY')}
                              </span>
                              <span style={{ width: '10%' }}><IconButton iconProps={{ iconName: "CloudDownload" }} title="CloudDownload" ariaLabel="CloudDownload"
                                onClick={() => this._downloadFile(_item["FileRef"])} />
                              </span>
                              <span style={{ width: '10%' }}><IconButton iconProps={{ iconName: "View" }} title="View" ariaLabel="View" />
                              </span>
                            </Stack.Item>
                          );
                        })}
                    </Stack>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStylesBlank}>
                    <div style={{ width: '50px' }}>
                      <Separator vertical />
                    </div>
                  </Stack.Item>
                  <Stack.Item grow={3} styles={stackItemStylesPane}>
                    <div style={{
                      border: '1px solid rgba(0, 0, 0, 0.3)',
                      height: '600px',
                      width: '100%'
                    }}>
                      <DocViewer pluginRenderers={DocViewerRenderers} style={{ width: '100%', height: "100%" }}
                        config={{
                          header: {
                            disableHeader: false,
                            disableFileName: false,
                            retainURLParams: false
                          }
                        }}
                        documents={[
                          {
                            uri: this.state.selectedPolicyFilePath
                          }
                        ]}
                      />
                    </div>
                  </Stack.Item>
                </Stack>
              </div>
            </PivotItem>
            <PivotItem headerText="LENDING/FINANCING TERMS" className={styles.customPivotHeader} >
              <div className={styles.pivotPane}>
                <h1>Lending/Financing Terms</h1>
                <Stack enableScopedSelectors horizontal tokens={stackTokens}>
                  <Stack.Item grow={2} styles={stackItemStylesList} className={styles.pivotPaneDocListContainer}>
                    <Stack enableScopedSelectors styles={stackStyles} tokens={itemAlignmentsStackTokens} style={{ margin: 10 }}>
                      {this.state.lendingPdfFiles.length > 0 &&
                        this.state.lendingPdfFiles.map((_item: any, i = 0) => {
                          return (
                            <Stack.Item align="auto" styles={stackItemStylesVertical} tabIndex={i + 1} onClick={() => this._selectFile(_item["FileRef"], 'lending', i + 1)} className={this.state.selectedLendingFileIndex == i + 1 ? styles['ifad-active'] : ''}>
                              <span dangerouslySetInnerHTML={{ __html: _item["FileLeafRef"] }} style={{ width: '50%' }}>
                              </span>
                              <span dangerouslySetInnerHTML={{ __html: _item["Language"] }} style={{ width: '15%' }}>
                              </span>
                              <span style={{ width: '15%' }}>
                                {moment(_item["Created"]).format('MMMM YYYY')}
                              </span>
                              <span style={{ width: '10%' }}><IconButton iconProps={{ iconName: "CloudDownload" }} title="CloudDownload" ariaLabel="CloudDownload"
                                onClick={() => this._downloadFile(_item["FileRef"])} />
                              </span>
                              <span style={{ width: '10%' }}><IconButton iconProps={{ iconName: "View" }} title="View" ariaLabel="View" />
                              </span>
                            </Stack.Item>
                          );
                        })}
                    </Stack>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStylesBlank}>
                    <div style={{ width: '50px' }}></div>
                  </Stack.Item>
                  <Stack.Item grow={3} styles={stackItemStylesPane}>
                    <div style={{
                      border: '1px solid rgba(0, 0, 0, 0.3)',
                      height: '600px',
                      width: '100%'
                    }}>
                      <DocViewer pluginRenderers={DocViewerRenderers} style={{ width: '100%', height: '100%' }}
                        config={{
                          header: {
                            disableHeader: false,
                            disableFileName: false,
                            retainURLParams: false
                          }
                        }}
                        documents={[
                          {
                            uri: this.state.selectedLendingFilePath
                          }
                        ]}
                      />
                    </div>
                  </Stack.Item>
                </Stack>
              </div>
            </PivotItem>
            <PivotItem headerText="DEBT SUSTAINIBILITY" className={styles.customPivotHeader} >
              <div className={styles.pivotPane}>
                <div className={styles.pivotPaneDebtSustain}>
                  <h2>
                    Debt Sustainability
                  </h2>
                  <h3>Introduction of IFAD DSF</h3>
                  <p>
                    The Debt Sustainability Framework (DSF) regulates the access to grant financing from IFAD's core resources. Eligible countries should be initially assessed as eligible for Highly Concessional terms. The framework considers the debt sustainability assessment of a country and its eligibility to access a certain level of grants resources using the IMF-WB Debt Sustainability Assessment (DSA). The exercise assesses the debt distress ratings to guide borrowing decisions in a way that matches countries' need for funds with their current and prospective ability to service debt, tailored to their specific circumstances. The classification of the risk of debt distress (low, moderate with substantial, some or limited space to absorb shocks, high or in debt distress) determines which IFAD financing terms are applicable to the eligible countries. As per the Debt Sustainability Framework Reform in September 2019, starting 2022 (IFAD 12) the DSF will provide financing in the form of grants or a combination of loans on Highly Concessional (HC) terms and Super Highly concessional terms (SHC).
                    Countries at moderate risk of debt distress with substantial space to absorb shocks will receive their PBAS allocation in the form of loans in Highly Concessional terms with small state amortization profile. Countries at moderate risk of debt distress with limited or some space to absorb shocks will receive 80% of their PBAS allocation in the form of loans in Super Highly Concessional terms and 20% of their PBAS allocation in the form of loans in Highly Concessional terms with small state amortization profile. Countries at in debt distress or at high risk of debt distress will receive 100% of their PBAS allocation as grant. The IMF-WB's approach to Debt Sustainability Analysis (DSA) differentiates between 1) Market-Access Countries (MACS), that typically have significant access to international capital markets, and 2) Low- Income Countries (LICs), which meet their external financings needs mostly through concessional resources. While the DSA for LICS clearly classifies the risk of debt distress (low, moderate with substantial, some or limited spare to absorb shocks, high or in debt distress), the MAC DSA framework does not necessarily define the rating but instead assess the overall debt sustainability
                  </p>
                </div>
              </div>
            </PivotItem>
          </Pivot>
          <Modal
            titleAriaId={"title"}
            className='ifadModal'
            isOpen={this.state.dataModal}
            onDismiss={() => { this.setState({ dataModal: false }) }}
            isBlocking={true}
            containerClassName={contentStyles.container}
          >
            <div className={contentStyles.header}>
              <h2 className={contentStyles.heading} id={"title"}>
                Country Snapshot
              </h2>
              <IconButton
                styles={iconButtonStyles}
                iconProps={{ iconName: 'Cancel' }}
                ariaLabel="Close popup modal"
                onClick={() => { this.setState({ dataModal: false }) }}
              />
            </div>
            <div className={contentStyles.body}>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas lorem nulla, malesuada ut sagittis sit
                amet, vulputate in leo. Maecenas vulputate congue sapien eu tincidunt. Etiam eu sem turpis. Fusce tempor
                sagittis nunc, ut interdum ipsum vestibulum non. Proin dolor elit, aliquam eget tincidunt non, vestibulum ut
                turpis. In hac habitasse platea dictumst. In a odio eget enim porttitor maximus. Aliquam nulla nibh,
                ullamcorper aliquam placerat eu, viverra et dui. Phasellus ex lectus, maximus in mollis ac, luctus vel eros.
                Vivamus ultrices, turpis sed malesuada gravida, eros ipsum venenatis elit, et volutpat eros dui et ante.
                Quisque ultricies mi nec leo ultricies mollis. Vivamus egestas volutpat lacinia. Quisque pharetra eleifend
                efficitur.
              </p>
            </div>
          </Modal>
        </div>
      </div>

    );
  }
}
