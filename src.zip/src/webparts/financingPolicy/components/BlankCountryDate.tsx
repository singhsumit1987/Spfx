import * as React from 'react';
import styles from './FinancingPolicy.module.scss';


export interface BlankDataProps {
    htmlContent: string;
}
class BlankCountryData extends React.Component<BlankDataProps> {
    constructor(props: BlankDataProps) {
        super(props);

    }
    render() {
        return <table className={styles.ifadTable}>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>Income Group:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>Least Developed Country:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>WB Fragility state list:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>Small State Economy:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>Commodity dependent country:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>IMF /WB DSA:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>Financing Terms:</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
            <tr className={styles.ifadRow}>
                <span className={styles.ifadRowStart}>IFAD 11 allocation (US$ million):</span>
                <span className={styles.ifadRowMid}> : </span>
                <span className={styles.ifadRowEnd}> </span>
            </tr>
        </table>;
    }
}

export default BlankCountryData;